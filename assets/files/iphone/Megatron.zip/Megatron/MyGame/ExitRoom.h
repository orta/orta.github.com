//
//  ExitRoom.h
//  Megatron
//
//  Created by orta therox on 28/07/2011.
//  Copyright 2011 http://ortatherox.com. All rights reserved.
//



@interface ExitRoom : Room

@end
