//
//  BodyGuard.h
//  MyBoots
//
//  Created by orta therox on 16/07/2011.
//  Copyright 2011 http://ortatherox.com. All rights reserved.
//

#import "Creature.h"

@interface BodyGuard : Creature

@end
