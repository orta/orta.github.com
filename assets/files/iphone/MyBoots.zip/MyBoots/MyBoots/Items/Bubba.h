//
//  Bubba.h
//  MyBoots
//
//  Created by orta therox on 11/07/2011.
//  Copyright 2011 http://ortatherox.com. All rights reserved.
//

#import "Item.h"

@interface Bubba : Item {
  int drinksLeft;
}

-(void) drink;

@end
