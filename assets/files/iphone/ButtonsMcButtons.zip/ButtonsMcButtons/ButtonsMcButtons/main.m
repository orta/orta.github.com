//
//  main.m
//  ButtonsMcButtons
//
//  Created by orta therox on 29/06/2011.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "ButtonsMcButtonsAppDelegate.h"

int main(int argc, char *argv[]) {
    NSAutoreleasePool *pool = [NSAutoreleasePool new];
    int retVal = UIApplicationMain(argc, argv, nil, @"ButtonsMcButtonsAppDelegate");
    [pool release];
    return retVal;
}
