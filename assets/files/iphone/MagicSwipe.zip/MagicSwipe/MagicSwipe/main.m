//
//  main.m
//  MagicSwipe
//
//  Created by orta therox on 03/07/2011.
//  Copyright 2011 http://ortatherox.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MagicSwipeAppDelegate.h"

int main(int argc, char *argv[]) {
  NSAutoreleasePool *pool = [NSAutoreleasePool new];
  int retVal = UIApplicationMain(argc, argv, nil, @"MagicSwipeAppDelegate");
  [pool release];
  return retVal;
}
