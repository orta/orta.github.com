//
//  ILikeSpringAppDelegate.h
//  ILikeSpring
//
//  Created by orta therox on 03/07/2011.
//  Copyright 2011 http://ortatherox.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ILikeSpringViewController;

@interface ILikeSpringAppDelegate : UIResponder <UIApplicationDelegate>

@property (retain, nonatomic) UIWindow *window;
@property (retain, nonatomic) ILikeSpringViewController *viewController;

@end
