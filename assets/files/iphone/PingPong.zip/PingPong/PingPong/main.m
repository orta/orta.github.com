
//
//  main.m
//  PingPong
//
//  Created by orta therox on 04/07/2011.
//  Copyright 2011 http://ortatherox.com. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "PingPongAppDelegate.h"

int main(int argc, char *argv[]) {
  NSAutoreleasePool *pool = [NSAutoreleasePool new];
  int retVal = UIApplicationMain(argc, argv, nil, @"PingPongAppDelegate");
  [pool release];
  return retVal;
}