//
//  GemClockAppDelegate.h
//  GemClock
//
//  Created by orta therox on 03/07/2011.
//  Copyright 2011 http://ortatherox.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@class GemClockViewController;

@interface GemClockAppDelegate : UIResponder <UIApplicationDelegate>

@property (retain, nonatomic) UIWindow *window;
@property (retain, nonatomic) GemClockViewController *viewController;

@end
