//
//  main.m
//  GemClock
//
//  Created by orta therox on 03/07/2011.
//  Copyright 2011 http://ortatherox.com. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "GemClockAppDelegate.h"

int main(int argc, char *argv[]) {
  NSAutoreleasePool *pool = [NSAutoreleasePool new];
  int retVal = UIApplicationMain(argc, argv, nil, @"GemClockAppDelegate");
  [pool release];
  return retVal;
}
