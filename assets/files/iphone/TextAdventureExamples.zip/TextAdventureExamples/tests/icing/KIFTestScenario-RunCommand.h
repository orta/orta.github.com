//
//  KIFTestScenario-RunCommand.h
//  WibbleQuest
//
//  Created by orta therox on 19/07/2011.
//  Copyright 2011 http://ortatherox.com. All rights reserved.
//

#import "KIFTestScenario.h"

@interface KIFTestScenario (KIFTestScenario_RunCommand)

- (void)runCommand:(NSString*)command;

@end
