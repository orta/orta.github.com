//
//  KIFScenario-Helpers.h
//  WibbleQuest
//
//  Created by orta therox on 23/07/2011.
//  Copyright 2011 http://ortatherox.com. All rights reserved.
//

#import "KIFTestScenario-RoomCommands.h"
#import "KIFTestScenario-RunCommand.h"