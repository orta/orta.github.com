//
//  StartingRoom.h
//  WibbleQuest
//
//  Created by orta therox on 17/07/2011.
//  Copyright 2011 http://ortatherox.com. All rights reserved.
//

#import "Room.h"

@interface StartingRoom : Room

@end
