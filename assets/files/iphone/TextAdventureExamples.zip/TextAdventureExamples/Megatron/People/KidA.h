//
//  KidA.h
//  Megatron
//
//  Created by orta therox on 26/07/2011.
//  Copyright 2011 http://ortatherox.com. All rights reserved.
//

#import "Person.h"

@interface KidA : Person {}

-(void) gotKid;
@property () bool faked;
@property () bool talked;
@property () bool caught;

@end
