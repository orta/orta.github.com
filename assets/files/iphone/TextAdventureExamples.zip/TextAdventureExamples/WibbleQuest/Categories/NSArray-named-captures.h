//
//  NSArray-named-captures.h
//  WibbleQuest
//
//  Created by orta therox on 17/07/2011.
//  Copyright 2011 http://ortatherox.com. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSArray (NSArray_named_captures)

- (id)first;
- (id)second;
- (id)third;
- (id)last;

@end
