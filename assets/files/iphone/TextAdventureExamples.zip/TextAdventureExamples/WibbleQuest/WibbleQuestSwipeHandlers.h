//
//  WibbleQuestSwipeHandlers.h
//  WibbleQuest
//
//  Created by orta therox on 31/07/2011.
//  Copyright 2011 http://ortatherox.com. All rights reserved.
//

#import "WibbleQuest.h"

@interface WibbleQuest (WibbleQuestSwipeHandling) 
-(void)setupCommandSwipes;
@end
