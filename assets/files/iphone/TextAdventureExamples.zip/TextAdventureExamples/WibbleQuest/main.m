//
//  main.m
//  WibbleQuest
//
//  Created by orta therox on 31/07/2011.
//  Copyright 2011 http://ortatherox.com. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
  return NSApplicationMain(argc, (const char **)argv);
}
