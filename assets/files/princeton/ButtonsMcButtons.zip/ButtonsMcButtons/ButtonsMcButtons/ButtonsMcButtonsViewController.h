//
//  ButtonsMcButtonsViewController.h
//  ButtonsMcButtons
//
//  Created by orta therox on 29/06/2011.
//  Copyright 2011 http://ortatherox.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ButtonsMcButtonsViewController : UIViewController

- (IBAction)thanksClicked:(id)sender;

@end
