//
//  ButtonsMcButtonsAppDelegate.h
//  ButtonsMcButtons
//
//  Created by orta therox on 29/06/2011.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ButtonsMcButtonsViewController;

@interface ButtonsMcButtonsAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) ButtonsMcButtonsViewController *viewController;

@end
