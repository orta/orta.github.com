//
//  WebbyBoyAppDelegate.h
//  WebbyBoy
//
//  Created by orta therox on 01/07/2011.
//  Copyright 2011 ortatherox.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@class WebbyBoyViewController;

@interface WebbyBoyAppDelegate : UIResponder <UIApplicationDelegate>

@property (retain, nonatomic) UIWindow *window;

@property (retain, nonatomic) WebbyBoyViewController *viewController;

@end
