//
//  main.m
//  WebbyBoy
//
//  Created by orta therox on 01/07/2011.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "WebbyBoyAppDelegate.h"

int main(int argc, char *argv[]) {
  NSAutoreleasePool *pool = [NSAutoreleasePool new];
  int retVal = UIApplicationMain(argc, argv, nil, @"WebbyBoyAppDelegate");
  [pool release];
  return retVal;
}
