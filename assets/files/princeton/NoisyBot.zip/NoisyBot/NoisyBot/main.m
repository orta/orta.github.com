//
//  main.m
//  NoisyBot
//
//  Created by orta therox on 30/06/2011.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "NoisyBotAppDelegate.h"

int main(int argc, char *argv[]) {
  NSAutoreleasePool *pool = [NSAutoreleasePool new];
  int retVal = UIApplicationMain(argc, argv, nil, @"NoisyBotAppDelegate");
  [pool release];
  return retVal;
}
