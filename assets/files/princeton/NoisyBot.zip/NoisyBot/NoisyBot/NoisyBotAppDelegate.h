//
//  NoisyBotAppDelegate.h
//  NoisyBot
//
//  Created by orta therox on 30/06/2011.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class NoisyBotViewController;

@interface NoisyBotAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) NoisyBotViewController *viewController;

@end
