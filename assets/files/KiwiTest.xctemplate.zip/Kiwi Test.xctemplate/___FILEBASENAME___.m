// A Kiwi Test for ___FILEBASENAME___
// http://www.kiwi-lib.info/

#import "Kiwi.h"

SPEC_BEGIN(___FILEBASENAME___)

describe(@"___FILEBASENAME___", ^{

      context(@"On loading", ^{
        __block NSObject *object = nil;
            
        beforeEach(^{ 
            object = [[NSObject alloc] init];
        });
        
        it(@"should exist", ^{
            [object shouldNotBeNil];
        });

    });
});

SPEC_END
